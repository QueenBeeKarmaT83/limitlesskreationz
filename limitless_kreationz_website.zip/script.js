document.addEventListener("DOMContentLoaded", function() {
    console.log("Limitless Kreationz website loaded successfully.");
});
